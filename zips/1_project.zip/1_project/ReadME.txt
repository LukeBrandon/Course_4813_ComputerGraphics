To operate this program, run the buildAndRun.sh script from the same directory
	as the source code

You will then be asked to choose the type of graph that you want to generate.

The read.cpp file will generate the commands for that type of graph, print them out,
	and also write them to the commands.txt file.

The graphs.cpp file will then read the commands.txt file and then run the OpenGL 
	commands to draw the selected graph type.

