c++ -Wall read.cpp -o read
c++ -Wall graphs.cpp -lGL -lGLU -lglut -o graphs

./read
./graphs

rm -f graphs read